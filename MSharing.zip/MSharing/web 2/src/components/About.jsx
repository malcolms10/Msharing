export default function About({text}) {
    return(
        <div className="h-screen ml-2 mt-4">
            {text}
        </div>
    )
}